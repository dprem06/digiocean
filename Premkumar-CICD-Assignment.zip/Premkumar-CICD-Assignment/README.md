# Node Api example: backend repository with plenty of details

PreRequisites:
Azure Subscription

# Local testing 
Optimised to work in local environments for demonstrative purposes.
// Azure cli login
az login

// Create Kubernetes Infrastructure using Teraform commands 
terraform init
terraform plan -out tfplan
terraform apply tfplan

// Push to docker container
az acr login --name conatinername
az acr show --name conatinername --query loginServer --output table
docker build -t node-express-api .
docker tag node-express-api conatinername.azurecr.io/node-express-api:v1
docker push conatinername.azurecr.io/node-express-api:v1
az acr repository list --name conatinername --output table

// AKS Login
az aks get-credentials --resource-group rgname --name kubernetes service name

kubectl config view
helm install node-express-api ./node-helm

### Verification Kubernetes Results
kubectl get all
kubectl get secrets

O/P:
C:\Users\H427928>kubectl get all
NAME                                  READY   STATUS    RESTARTS   AGE
pod/api-db                            1/1     Running   0          83m
pod/api-deployment-649c96bd7f-lkxg9   1/1     Running   0          29m

NAME                 TYPE        CLUSTER-IP    EXTERNAL-IP   PORT(S)        AGE
service/apiservice   NodePort    10.0.154.21   <none>        80:30158/TCP   83m
service/kubernetes   ClusterIP   10.0.0.1      <none>        443/TCP        39h

NAME                             READY   UP-TO-DATE   AVAILABLE   AGE
deployment.apps/api-deployment   1/1     1            1           83m

NAME                                        DESIRED   CURRENT   READY   AGE
replicaset.apps/api-deployment-649c96bd7f   1         1         1       29m
replicaset.apps/api-deployment-6ff69f88c4   0         0         0       83m


### Teraform (IAC)
 1) Resource Group
 2) Service Principle for Authenticate
 3) Container Registry(ACR)
 4) Kuberneties Service(AKS)

Teraform Commands:
terraform init
terraform plan -out tfplan
terraform apply tfplan

### Docker
Install Docker on your Machine Or Cloud.

```
docker build -t node-express-api .
docker push node-express-api:latest to contailer registry(Azure Container Registry) 

```

### Helm Chart
Check `values.yaml` points to the image you've built, e.g. `NODE_AKS:v1`.

Deploy MYSQL into your cluster 

Deploy this Node.js application into your kubernetes cluster(AKS) with  `helm install --name backend node-helm`. 

This Node.js application connects to the MySQL service.

### Using Postman

Assuming you've deployed to Kubernetes (notice the bigger port number here: this is the specified NodePort which will be used when you Helm install its chart):

GET to `clusterip:3000/` with, for example:
```
{
	"hello": "world",
}

GET to `clusterip:3000/users` with, for example:
```
{
	"firstName": "firstName",
    "lastName": "lastName"
}
```

### Cleaning up
- `terraform destroy` Destroy the services from azure cloud
- `helm delete --purge backend` uninstalls the Node.js backend application